<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('m_detil_periodes', function (Blueprint $table) {
            $table->Increments('detil_periode_id');
            $table->unsignedInteger('periode_id');
            $table->unsignedTinyInteger('jalur_id');
            $table->unsignedTinyInteger('tahapan_id');
            $table->foreign('periode_id')->references('periode_id')->on('m_periodes');
            $table->foreign('jalur_id')->references('jalur_id')->on('m_jalurs');
            $table->foreign('tahapan_id')->references('tahapan_id')->on('m_tahapans');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('m_detil_periodes');
    }
};
